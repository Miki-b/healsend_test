import React from 'react';
import { motion } from 'framer-motion';
import { Zap, Sparkles, Dna } from 'lucide-react';

const goals = [
  {
    id: 'energy',
    tag: 'Energy',
    icon: Zap,
    title: 'Eliminate Brain Fog',
    subtitle: 'Restore mental clarity & all-day energy',
    gradient: 'from-amber-400 to-orange-500',
    glow: 'bg-amber-500/20'
  },
  {
    id: 'glow',
    tag: 'Glow',
    icon: Sparkles,
    title: 'Skin Glow & Detox',
    subtitle: 'Radiant complexion from the inside out',
    gradient: 'from-rose-400 to-pink-500',
    glow: 'bg-rose-500/20'
  },
  {
    id: 'all',
    tag: 'All',
    icon: Dna,
    title: 'Total Cellular Renewal',
    subtitle: 'The complete longevity transformation',
    gradient: 'from-emerald-400 to-teal-500',
    glow: 'bg-emerald-500/20'
  }
];

export default function GoalScreen({ onSelect }) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 py-16">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="text-center mb-12"
      >
        <span className="inline-block px-4 py-1.5 rounded-full bg-emerald-500/10 text-emerald-400 text-sm font-medium mb-6 border border-emerald-500/20">
          Step 1 of 3
        </span>
        <h1 className="text-4xl md:text-5xl font-light text-white mb-4 tracking-tight">
          What's your <span className="font-semibold bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">primary goal</span>?
        </h1>
        <p className="text-slate-400 text-lg max-w-md mx-auto">
          Select the outcome that matters most to you right now
        </p>
      </motion.div>

      <div className="w-full max-w-lg space-y-4">
        {goals.map((goal, index) => (
          <motion.button
            key={goal.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 + index * 0.1 }}
            onClick={() => onSelect(goal.tag)}
            className="w-full group relative"
          >
            <div className={`absolute inset-0 ${goal.glow} rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
            <div className="relative flex items-center gap-5 p-6 rounded-2xl bg-slate-800/50 border border-slate-700/50 hover:border-slate-600 hover:bg-slate-800/80 transition-all duration-300">
              <div className={`flex-shrink-0 w-14 h-14 rounded-xl bg-gradient-to-br ${goal.gradient} flex items-center justify-center shadow-lg`}>
                <goal.icon className="w-7 h-7 text-white" />
              </div>
              <div className="text-left flex-1">
                <h3 className="text-lg font-semibold text-white mb-1">{goal.title}</h3>
                <p className="text-slate-400 text-sm">{goal.subtitle}</p>
              </div>
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-slate-700/50 flex items-center justify-center group-hover:bg-emerald-500/20 group-hover:text-emerald-400 transition-all">
                <svg className="w-4 h-4 text-slate-500 group-hover:text-emerald-400 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </div>
          </motion.button>
        ))}
      </div>
    </div>
  );
}